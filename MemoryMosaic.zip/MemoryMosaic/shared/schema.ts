import { pgTable, text, serial, integer, boolean, timestamp, varchar, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").unique(),
  fullName: text("full_name"),
  role: text("role").default("user"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastLogin: timestamp("last_login"),
});

export const mqlScripts = pgTable("mql_scripts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  code: text("code").notNull(),
  version: text("version").default("1.0"),
  type: text("type").notNull(), // indicator, expert, script
  category: text("category"), // trend, oscillator, etc.
  isPublic: boolean("is_public").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const mqlSnippets = pgTable("mql_snippets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  code: text("code").notNull(),
  description: text("description"),
  tags: text("tags").array(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const studyLibrary = pgTable("study_library", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull(),
  tags: text("tags").array(),
  createdBy: integer("created_by").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const aiConversations = pgTable("ai_conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const aiMessages = pgTable("ai_messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull(),
  content: text("content").notNull(),
  fromUser: boolean("from_user").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  metadata: json("metadata"),
});

export const backtest = pgTable("backtest", {
  id: serial("id").primaryKey(),
  scriptId: integer("script_id").notNull(),
  userId: integer("user_id").notNull(),
  parameters: json("parameters"),
  results: json("results"),
  symbol: text("symbol").notNull(),
  timeframe: text("timeframe").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const errorLogs = pgTable("error_logs", {
  id: serial("id").primaryKey(),
  scriptId: integer("script_id"),
  userId: integer("user_id").notNull(),
  errorCode: integer("error_code"),
  message: text("message").notNull(),
  stackTrace: text("stack_trace"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  theme: text("theme").default("light"),
  editorFontSize: integer("editor_font_size").default(14),
  editorTheme: text("editor_theme").default("vs-light"),
  autoSave: boolean("auto_save").default(true),
  preferences: json("preferences"),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastLogin: true,
});

export const insertMqlScriptSchema = createInsertSchema(mqlScripts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMqlSnippetSchema = createInsertSchema(mqlSnippets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertStudyLibrarySchema = createInsertSchema(studyLibrary).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAiConversationSchema = createInsertSchema(aiConversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAiMessageSchema = createInsertSchema(aiMessages).omit({
  id: true,
  timestamp: true,
});

export const insertBacktestSchema = createInsertSchema(backtest).omit({
  id: true,
  createdAt: true,
});

export const insertErrorLogSchema = createInsertSchema(errorLogs).omit({
  id: true,
  timestamp: true,
});

export const insertUserPreferencesSchema = createInsertSchema(userPreferences).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type MqlScript = typeof mqlScripts.$inferSelect;
export type InsertMqlScript = z.infer<typeof insertMqlScriptSchema>;

export type MqlSnippet = typeof mqlSnippets.$inferSelect;
export type InsertMqlSnippet = z.infer<typeof insertMqlSnippetSchema>;

export type StudyLibrary = typeof studyLibrary.$inferSelect;
export type InsertStudyLibrary = z.infer<typeof insertStudyLibrarySchema>;

export type AiConversation = typeof aiConversations.$inferSelect;
export type InsertAiConversation = z.infer<typeof insertAiConversationSchema>;

export type AiMessage = typeof aiMessages.$inferSelect;
export type InsertAiMessage = z.infer<typeof insertAiMessageSchema>;

export type Backtest = typeof backtest.$inferSelect;
export type InsertBacktest = z.infer<typeof insertBacktestSchema>;

export type ErrorLog = typeof errorLogs.$inferSelect;
export type InsertErrorLog = z.infer<typeof insertErrorLogSchema>;

export type UserPreferences = typeof userPreferences.$inferSelect;
export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;
