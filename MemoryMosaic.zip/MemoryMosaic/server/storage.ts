import type { 
  User, InsertUser,
  MqlScript, InsertMqlScript,
  MqlSnippet, InsertMqlSnippet,
  StudyLibrary, InsertStudyLibrary,
  AiConversation, InsertAiConversation,
  AiMessage, InsertAiMessage,
  Backtest, InsertBacktest,
  ErrorLog, InsertErrorLog,
  UserPreferences, InsertUserPreferences
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // MQL Script operations
  getMqlScript(id: number): Promise<MqlScript | undefined>;
  getMqlScriptsByUserId(userId: number): Promise<MqlScript[]>;
  createMqlScript(script: InsertMqlScript): Promise<MqlScript>;
  updateMqlScript(id: number, script: Partial<InsertMqlScript>): Promise<MqlScript | undefined>;
  deleteMqlScript(id: number): Promise<boolean>;

  // MQL Snippet operations
  getMqlSnippet(id: number): Promise<MqlSnippet | undefined>;
  getMqlSnippetsByUserId(userId: number): Promise<MqlSnippet[]>;
  createMqlSnippet(snippet: InsertMqlSnippet): Promise<MqlSnippet>;
  updateMqlSnippet(id: number, snippet: Partial<InsertMqlSnippet>): Promise<MqlSnippet | undefined>;
  deleteMqlSnippet(id: number): Promise<boolean>;

  // Study Library operations
  getStudyLibraryItem(id: number): Promise<StudyLibrary | undefined>;
  getStudyLibraryByCategory(category: string): Promise<StudyLibrary[]>;
  createStudyLibraryItem(item: InsertStudyLibrary): Promise<StudyLibrary>;
  updateStudyLibraryItem(id: number, item: Partial<InsertStudyLibrary>): Promise<StudyLibrary | undefined>;
  deleteStudyLibraryItem(id: number): Promise<boolean>;

  // AI Conversation operations
  getAiConversation(id: number): Promise<AiConversation | undefined>;
  getAiConversationsByUserId(userId: number): Promise<AiConversation[]>;
  createAiConversation(conversation: InsertAiConversation): Promise<AiConversation>;
  updateAiConversation(id: number, conversation: Partial<InsertAiConversation>): Promise<AiConversation | undefined>;
  deleteAiConversation(id: number): Promise<boolean>;

  // AI Message operations
  getAiMessagesByConversationId(conversationId: number): Promise<AiMessage[]>;
  createAiMessage(message: InsertAiMessage): Promise<AiMessage>;

  // Backtest operations
  getBacktest(id: number): Promise<Backtest | undefined>;
  getBacktestsByUserId(userId: number): Promise<Backtest[]>;
  getBacktestsByScriptId(scriptId: number): Promise<Backtest[]>;
  createBacktest(test: InsertBacktest): Promise<Backtest>;
  deleteBacktest(id: number): Promise<boolean>;

  // Error Log operations
  getErrorLog(id: number): Promise<ErrorLog | undefined>;
  getErrorLogsByUserId(userId: number): Promise<ErrorLog[]>;
  createErrorLog(log: InsertErrorLog): Promise<ErrorLog>;

  // User Preferences operations
  getUserPreferences(userId: number): Promise<UserPreferences | undefined>;
  createOrUpdateUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private mqlScripts: Map<number, MqlScript>;
  private mqlSnippets: Map<number, MqlSnippet>;
  private studyLibrary: Map<number, StudyLibrary>;
  private aiConversations: Map<number, AiConversation>;
  private aiMessages: Map<number, AiMessage>;
  private backtests: Map<number, Backtest>;
  private errorLogs: Map<number, ErrorLog>;
  private userPreferencesMap: Map<number, UserPreferences>;
  
  private userId: number;
  private mqlScriptId: number;
  private mqlSnippetId: number;
  private studyLibraryId: number;
  private aiConversationId: number;
  private aiMessageId: number;
  private backtestId: number;
  private errorLogId: number;
  private userPreferencesId: number;

  constructor() {
    this.users = new Map();
    this.mqlScripts = new Map();
    this.mqlSnippets = new Map();
    this.studyLibrary = new Map();
    this.aiConversations = new Map();
    this.aiMessages = new Map();
    this.backtests = new Map();
    this.errorLogs = new Map();
    this.userPreferencesMap = new Map();
    
    this.userId = 1;
    this.mqlScriptId = 1;
    this.mqlSnippetId = 1;
    this.studyLibraryId = 1;
    this.aiConversationId = 1;
    this.aiMessageId = 1;
    this.backtestId = 1;
    this.errorLogId = 1;
    this.userPreferencesId = 1;

    // Create a default user
    this.createUser({ 
      username: "admin",
      password: "admin",
      email: "admin@example.com",
      fullName: "Administrator",
      role: "admin"
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const newUser: User = { 
      ...user, 
      id, 
      createdAt: now,
      lastLogin: null,
      email: user.email || null,
      fullName: user.fullName || null,
      role: user.role || "user"
    };
    this.users.set(id, newUser);
    return newUser;
  }

  // MQL Script operations
  async getMqlScript(id: number): Promise<MqlScript | undefined> {
    return this.mqlScripts.get(id);
  }

  async getMqlScriptsByUserId(userId: number): Promise<MqlScript[]> {
    return Array.from(this.mqlScripts.values()).filter(
      (script) => script.userId === userId,
    );
  }

  async createMqlScript(script: InsertMqlScript): Promise<MqlScript> {
    const id = this.mqlScriptId++;
    const now = new Date();
    const newScript: MqlScript = { 
      ...script, 
      id, 
      createdAt: now,
      updatedAt: now
    };
    this.mqlScripts.set(id, newScript);
    return newScript;
  }

  async updateMqlScript(id: number, script: Partial<InsertMqlScript>): Promise<MqlScript | undefined> {
    const existingScript = this.mqlScripts.get(id);
    if (!existingScript) return undefined;

    const updatedScript: MqlScript = { 
      ...existingScript, 
      ...script, 
      updatedAt: new Date() 
    };
    this.mqlScripts.set(id, updatedScript);
    return updatedScript;
  }

  async deleteMqlScript(id: number): Promise<boolean> {
    return this.mqlScripts.delete(id);
  }

  // MQL Snippet operations
  async getMqlSnippet(id: number): Promise<MqlSnippet | undefined> {
    return this.mqlSnippets.get(id);
  }

  async getMqlSnippetsByUserId(userId: number): Promise<MqlSnippet[]> {
    return Array.from(this.mqlSnippets.values()).filter(
      (snippet) => snippet.userId === userId,
    );
  }

  async createMqlSnippet(snippet: InsertMqlSnippet): Promise<MqlSnippet> {
    const id = this.mqlSnippetId++;
    const now = new Date();
    const newSnippet: MqlSnippet = { 
      ...snippet, 
      id, 
      createdAt: now,
      updatedAt: now
    };
    this.mqlSnippets.set(id, newSnippet);
    return newSnippet;
  }

  async updateMqlSnippet(id: number, snippet: Partial<InsertMqlSnippet>): Promise<MqlSnippet | undefined> {
    const existingSnippet = this.mqlSnippets.get(id);
    if (!existingSnippet) return undefined;

    const updatedSnippet: MqlSnippet = { 
      ...existingSnippet, 
      ...snippet, 
      updatedAt: new Date() 
    };
    this.mqlSnippets.set(id, updatedSnippet);
    return updatedSnippet;
  }

  async deleteMqlSnippet(id: number): Promise<boolean> {
    return this.mqlSnippets.delete(id);
  }

  // Study Library operations
  async getStudyLibraryItem(id: number): Promise<StudyLibrary | undefined> {
    return this.studyLibrary.get(id);
  }

  async getStudyLibraryByCategory(category: string): Promise<StudyLibrary[]> {
    return Array.from(this.studyLibrary.values()).filter(
      (item) => item.category === category,
    );
  }

  async createStudyLibraryItem(item: InsertStudyLibrary): Promise<StudyLibrary> {
    const id = this.studyLibraryId++;
    const now = new Date();
    const newItem: StudyLibrary = { 
      ...item, 
      id, 
      createdAt: now,
      updatedAt: now
    };
    this.studyLibrary.set(id, newItem);
    return newItem;
  }

  async updateStudyLibraryItem(id: number, item: Partial<InsertStudyLibrary>): Promise<StudyLibrary | undefined> {
    const existingItem = this.studyLibrary.get(id);
    if (!existingItem) return undefined;

    const updatedItem: StudyLibrary = { 
      ...existingItem, 
      ...item, 
      updatedAt: new Date() 
    };
    this.studyLibrary.set(id, updatedItem);
    return updatedItem;
  }

  async deleteStudyLibraryItem(id: number): Promise<boolean> {
    return this.studyLibrary.delete(id);
  }

  // AI Conversation operations
  async getAiConversation(id: number): Promise<AiConversation | undefined> {
    return this.aiConversations.get(id);
  }

  async getAiConversationsByUserId(userId: number): Promise<AiConversation[]> {
    return Array.from(this.aiConversations.values()).filter(
      (conversation) => conversation.userId === userId,
    );
  }

  async createAiConversation(conversation: InsertAiConversation): Promise<AiConversation> {
    const id = this.aiConversationId++;
    const now = new Date();
    const newConversation: AiConversation = { 
      ...conversation, 
      id, 
      createdAt: now,
      updatedAt: now
    };
    this.aiConversations.set(id, newConversation);
    return newConversation;
  }

  async updateAiConversation(id: number, conversation: Partial<InsertAiConversation>): Promise<AiConversation | undefined> {
    const existingConversation = this.aiConversations.get(id);
    if (!existingConversation) return undefined;

    const updatedConversation: AiConversation = { 
      ...existingConversation, 
      ...conversation, 
      updatedAt: new Date() 
    };
    this.aiConversations.set(id, updatedConversation);
    return updatedConversation;
  }

  async deleteAiConversation(id: number): Promise<boolean> {
    // Also delete all messages in this conversation
    Array.from(this.aiMessages.values())
      .filter(msg => msg.conversationId === id)
      .forEach(msg => this.aiMessages.delete(msg.id));
    
    return this.aiConversations.delete(id);
  }

  // AI Message operations
  async getAiMessagesByConversationId(conversationId: number): Promise<AiMessage[]> {
    return Array.from(this.aiMessages.values())
      .filter(message => message.conversationId === conversationId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime()); // Sort by timestamp
  }

  async createAiMessage(message: InsertAiMessage): Promise<AiMessage> {
    const id = this.aiMessageId++;
    const newMessage: AiMessage = { 
      ...message, 
      id, 
      timestamp: new Date(),
      metadata: message.metadata || null
    };
    this.aiMessages.set(id, newMessage);
    return newMessage;
  }

  // Backtest operations
  async getBacktest(id: number): Promise<Backtest | undefined> {
    return this.backtests.get(id);
  }

  async getBacktestsByUserId(userId: number): Promise<Backtest[]> {
    return Array.from(this.backtests.values()).filter(
      (test) => test.userId === userId,
    );
  }

  async getBacktestsByScriptId(scriptId: number): Promise<Backtest[]> {
    return Array.from(this.backtests.values()).filter(
      (test) => test.scriptId === scriptId,
    );
  }

  async createBacktest(test: InsertBacktest): Promise<Backtest> {
    const id = this.backtestId++;
    const newTest: Backtest = { 
      ...test, 
      id, 
      createdAt: new Date()
    };
    this.backtests.set(id, newTest);
    return newTest;
  }

  async deleteBacktest(id: number): Promise<boolean> {
    return this.backtests.delete(id);
  }

  // Error Log operations
  async getErrorLog(id: number): Promise<ErrorLog | undefined> {
    return this.errorLogs.get(id);
  }

  async getErrorLogsByUserId(userId: number): Promise<ErrorLog[]> {
    return Array.from(this.errorLogs.values()).filter(
      (log) => log.userId === userId,
    );
  }

  async createErrorLog(log: InsertErrorLog): Promise<ErrorLog> {
    const id = this.errorLogId++;
    const newLog: ErrorLog = { 
      ...log, 
      id, 
      timestamp: new Date(),
      scriptId: log.scriptId || null,
      errorCode: log.errorCode || null,
      stackTrace: log.stackTrace || null
    };
    this.errorLogs.set(id, newLog);
    return newLog;
  }

  // User Preferences operations
  async getUserPreferences(userId: number): Promise<UserPreferences | undefined> {
    return Array.from(this.userPreferencesMap.values()).find(
      (prefs) => prefs.userId === userId
    );
  }

  async createOrUpdateUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences> {
    const existingPrefs = await this.getUserPreferences(preferences.userId);
    
    if (existingPrefs) {
      // Update existing preferences
      const updatedPrefs: UserPreferences = {
        ...existingPrefs,
        ...preferences
      };
      this.userPreferencesMap.set(existingPrefs.id, updatedPrefs);
      return updatedPrefs;
    } else {
      // Create new preferences
      const id = this.userPreferencesId++;
      const newPrefs: UserPreferences = {
        ...preferences,
        id,
        theme: preferences.theme || "light",
        editorFontSize: preferences.editorFontSize || 14,
        editorTheme: preferences.editorTheme || "vs-light",
        autoSave: preferences.autoSave !== undefined ? preferences.autoSave : true,
        preferences: preferences.preferences || null
      };
      this.userPreferencesMap.set(id, newPrefs);
      return newPrefs;
    }
  }
}

// For basic in-memory storage during development
export const memStorage = new MemStorage();

// For production database storage
import { DatabaseStorage } from "./DatabaseStorage";
export const dbStorage = new DatabaseStorage();

// Use database storage by default
export const storage = dbStorage;
