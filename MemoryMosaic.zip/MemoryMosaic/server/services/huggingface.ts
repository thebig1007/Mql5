/**
 * Serviço para interagir com a API do Hugging Face
 */

import fetch from 'node-fetch';

// URL base para a API de inferência do Hugging Face
const HF_API_URL = 'https://api-inference.huggingface.co/models';

// Token de API do Hugging Face
const HF_API_TOKEN = process.env.HF_API_TOKEN;

// Verificar se o token está configurado
if (!HF_API_TOKEN) {
  console.warn('HF_API_TOKEN não está configurado! A API do Hugging Face não funcionará corretamente.');
}

// Modelo padrão para geração de código MQL5 - usando um modelo menor mais disponível
const DEFAULT_CODE_GENERATION_MODEL = 'Xenova/codellama-7b-instruct-awq';

// Modelo padrão para responder perguntas
const DEFAULT_QA_MODEL = 'Xenova/llama-2-7b-chat';

// Opções padrão para a API
const defaultOptions = {
  wait_for_model: true,
  use_cache: true
};

/**
 * Função que gera código MQL5 a partir de uma descrição
 */
export async function generateMQL5Code(prompt: string, model = DEFAULT_CODE_GENERATION_MODEL): Promise<string> {
  try {
    const systemPrompt = "Você é um especialista em programação MQL5 para MetaTrader 5. Gere código MQL5 limpo, eficiente e bem comentado com base na descrição fornecida.";
    const fullPrompt = `${systemPrompt}\n\nDescriçao: ${prompt}\n\nCódigo MQL5:`;
    
    const response = await fetch(`${HF_API_URL}/${model}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${HF_API_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        inputs: fullPrompt,
        parameters: {
          max_new_tokens: 1024,
          temperature: 0.2,
          top_p: 0.95,
          return_full_text: false,
          ...defaultOptions
        }
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Falha ao gerar código: ${response.status} - ${JSON.stringify(errorData)}`);
    }

    const data = await response.json();
    if (Array.isArray(data) && data.length > 0) {
      return data[0].generated_text.trim();
    }

    return data.generated_text || 'Não foi possível gerar código.';
  } catch (error) {
    console.error('Erro na geração de código:', error);
    throw new Error(`Erro na geração de código: ${error.message}`);
  }
}

/**
 * Função que corrige e otimiza código MQL5 existente
 */
export async function improveMQL5Code(code: string, instructions: string, model = DEFAULT_CODE_GENERATION_MODEL): Promise<string> {
  try {
    const systemPrompt = "Você é um especialista em programação MQL5 para MetaTrader 5. Melhore, corrija e otimize o código MQL5 fornecido de acordo com as instruções.";
    const fullPrompt = `${systemPrompt}\n\nCódigo Original:\n\`\`\`mql5\n${code}\n\`\`\`\n\nInstruções: ${instructions}\n\nCódigo Melhorado:`;
    
    const response = await fetch(`${HF_API_URL}/${model}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${HF_API_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        inputs: fullPrompt,
        parameters: {
          max_new_tokens: 2048,
          temperature: 0.1,
          top_p: 0.95,
          return_full_text: false,
          ...defaultOptions
        }
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Falha ao melhorar código: ${response.status} - ${JSON.stringify(errorData)}`);
    }

    const data = await response.json();
    if (Array.isArray(data) && data.length > 0) {
      return data[0].generated_text.trim();
    }

    return data.generated_text || 'Não foi possível melhorar o código.';
  } catch (error) {
    console.error('Erro na melhoria de código:', error);
    throw new Error(`Erro na melhoria de código: ${error.message}`);
  }
}

/**
 * Função que analisa código MQL5 e detecta problemas
 */
export async function analyzeMQL5Code(code: string, model = DEFAULT_CODE_GENERATION_MODEL): Promise<string> {
  try {
    const systemPrompt = "Você é um especialista em programação MQL5 para MetaTrader 5. Analise o código MQL5 fornecido e identifique possíveis problemas, bugs, vazamentos de memória, erros de lógica e práticas não recomendadas.";
    const fullPrompt = `${systemPrompt}\n\nCódigo para Análise:\n\`\`\`mql5\n${code}\n\`\`\`\n\nAnálise Detalhada:`;
    
    const response = await fetch(`${HF_API_URL}/${model}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${HF_API_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        inputs: fullPrompt,
        parameters: {
          max_new_tokens: 1024,
          temperature: 0.1,
          top_p: 0.95,
          return_full_text: false,
          ...defaultOptions
        }
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Falha ao analisar código: ${response.status} - ${JSON.stringify(errorData)}`);
    }

    const data = await response.json();
    if (Array.isArray(data) && data.length > 0) {
      return data[0].generated_text.trim();
    }

    return data.generated_text || 'Não foi possível analisar o código.';
  } catch (error) {
    console.error('Erro na análise de código:', error);
    throw new Error(`Erro na análise de código: ${error.message}`);
  }
}

/**
 * Função que responde perguntas gerais sobre MQL5 e MetaTrader
 */
export async function answerQuestion(question: string, model = DEFAULT_QA_MODEL): Promise<string> {
  try {
    const systemPrompt = "Você é um assistente especializado em programação MQL5 para MetaTrader 5. Responda de forma clara, precisa e objetiva às perguntas sobre MQL5, MetaTrader e trading algorítmico.";
    const fullPrompt = `${systemPrompt}\n\nPergunta: ${question}\n\nResposta:`;
    
    const response = await fetch(`${HF_API_URL}/${model}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${HF_API_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        inputs: fullPrompt,
        parameters: {
          max_new_tokens: 1024,
          temperature: 0.3,
          top_p: 0.9,
          return_full_text: false,
          ...defaultOptions
        }
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Falha ao responder pergunta: ${response.status} - ${JSON.stringify(errorData)}`);
    }

    const data = await response.json();
    if (Array.isArray(data) && data.length > 0) {
      return data[0].generated_text.trim();
    }

    return data.generated_text || 'Não foi possível responder à pergunta.';
  } catch (error) {
    console.error('Erro ao responder pergunta:', error);
    throw new Error(`Erro ao responder pergunta: ${error.message}`);
  }
}

/**
 * Função que continua uma conversa com base em mensagens anteriores
 */
export async function continueChatConversation(messages: {role: string, content: string}[], model = DEFAULT_QA_MODEL): Promise<string> {
  try {
    // Formatar as mensagens como texto
    const systemPrompt = "Você é um assistente especializado em programação MQL5 para MetaTrader 5. Seu objetivo é ajudar com programação, responder perguntas técnicas e fornecer orientações sobre trading algorítmico.";
    
    let conversationText = systemPrompt + "\n\n";
    messages.forEach(msg => {
      const role = msg.role === 'user' ? 'Usuário' : 'Assistente';
      conversationText += `${role}: ${msg.content}\n\n`;
    });
    
    conversationText += "Assistente:";
    
    const response = await fetch(`${HF_API_URL}/${model}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${HF_API_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        inputs: conversationText,
        parameters: {
          max_new_tokens: 1024,
          temperature: 0.5,
          top_p: 0.9,
          return_full_text: false,
          ...defaultOptions
        }
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Falha na conversa: ${response.status} - ${JSON.stringify(errorData)}`);
    }

    const data = await response.json();
    if (Array.isArray(data) && data.length > 0) {
      return data[0].generated_text.trim();
    }

    return data.generated_text || 'Não foi possível continuar a conversa.';
  } catch (error) {
    console.error('Erro na conversa:', error);
    throw new Error(`Erro na conversa: ${error.message}`);
  }
}