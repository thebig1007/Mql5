/**
 * Controlador para funcionalidades de IA
 * Gerencia funções relacionadas à geração, análise e melhoria de código MQL5
 */

import { Request, Response } from 'express';
import { storage } from '../storage';
import { 
  answerQuestion, 
  generateMQL5Code, 
  improveMQL5Code, 
  analyzeMQL5Code, 
  continueChatConversation 
} from '../services/huggingface';

/**
 * Gera código MQL5 a partir de uma descrição textual
 */
export async function generateCode(req: Request, res: Response) {
  try {
    const { prompt, model } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt é obrigatório' });
    }

    const code = await generateMQL5Code(prompt, model);
    res.json({ generatedCode: code });
  } catch (error) {
    console.error('Erro ao gerar código:', error);
    res.status(500).json({ error: 'Falha ao gerar código MQL5' });
  }
}

/**
 * Melhora e otimiza código MQL5 existente
 */
export async function improveCode(req: Request, res: Response) {
  try {
    const { code, instructions, model } = req.body;

    if (!code) {
      return res.status(400).json({ error: 'Código é obrigatório' });
    }

    const improvedCode = await improveMQL5Code(
      code, 
      instructions || 'Melhore, otimize e corrija este código', 
      model
    );
    res.json({ improvedCode });
  } catch (error) {
    console.error('Erro ao melhorar código:', error);
    res.status(500).json({ error: 'Falha ao melhorar código MQL5' });
  }
}

/**
 * Analisa código MQL5 e identifica problemas
 */
export async function analyzeCode(req: Request, res: Response) {
  try {
    const { code, model } = req.body;

    if (!code) {
      return res.status(400).json({ error: 'Código é obrigatório' });
    }

    const analysis = await analyzeMQL5Code(code, model);
    res.json({ analysis });
  } catch (error) {
    console.error('Erro ao analisar código:', error);
    res.status(500).json({ error: 'Falha ao analisar código MQL5' });
  }
}

/**
 * Responde a uma pergunta sobre MQL5 ou trading algorítmico
 */
export async function askQuestion(req: Request, res: Response) {
  try {
    const { question, model } = req.body;

    if (!question) {
      return res.status(400).json({ error: 'Pergunta é obrigatória' });
    }

    const answer = await answerQuestion(question, model);
    res.json({ answer });
  } catch (error) {
    console.error('Erro ao responder pergunta:', error);
    res.status(500).json({ error: 'Falha ao responder pergunta' });
  }
}

/**
 * Recebe uma mensagem e continua a conversa atual
 */
export async function sendMessage(req: Request, res: Response) {
  try {
    const { conversationId, content, model } = req.body;
    const userId = 1; // Temporário, até implementar autenticação

    if (!conversationId || !content) {
      return res.status(400).json({ error: 'ID de conversa e conteúdo são obrigatórios' });
    }

    // Obter a conversa e verificar se existe
    const conversation = await storage.getAiConversation(conversationId);
    if (!conversation) {
      return res.status(404).json({ error: 'Conversa não encontrada' });
    }

    // Criar mensagem do usuário
    const userMessage = await storage.createAiMessage({
      conversationId,
      content,
      role: 'user',
      timestamp: new Date(),
      metadata: null
    });

    // Obter todas as mensagens da conversa
    const allMessages = await storage.getAiMessagesByConversationId(conversationId);
    
    // Converter para o formato esperado pela API
    const formattedMessages = allMessages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));

    // Obter resposta do modelo
    const assistantResponse = await continueChatConversation(formattedMessages, model);

    // Salvar resposta do assistente
    const aiMessage = await storage.createAiMessage({
      conversationId,
      content: assistantResponse,
      role: 'assistant',
      timestamp: new Date(),
      metadata: null
    });

    // Retornar ambas as mensagens
    res.json({
      userMessage,
      aiMessage
    });
  } catch (error) {
    console.error('Erro ao enviar mensagem:', error);
    res.status(500).json({ error: 'Falha ao processar mensagem' });
  }
}