import type { Express, Request, Response, NextFunction } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { insertMqlScriptSchema, insertMqlSnippetSchema, insertStudyLibrarySchema, insertAiMessageSchema } from "@shared/schema";
import { z } from "zod";

// Configure multer for handling file uploads
const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage2 = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (_req, file, cb) => {
    // Create a unique filename
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, `${file.fieldname}-${uniqueSuffix}${ext}`);
  },
});

const upload = multer({
  storage: storage2,
  limits: {
    fileSize: 20 * 1024 * 1024, // 20MB limit
  },
  fileFilter: (_req, file, cb) => {
    // Accept only image files
    const allowedTypes = [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/webp",
      "image/heic",
    ];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only JPEG, PNG, GIF, WEBP, and HEIC are allowed."));
    }
  },
});

// Validate userId middleware
const validateUserId = (req: Request, res: Response, next: Function) => {
  // For simplicity, we'll use a hardcoded user ID of 1
  // In a real application, this would come from authentication
  req.body.userId = req.body.userId || 1;
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  app.use("/api", validateUserId);

  // MQL Script routes
  app.get("/api/scripts", async (req, res) => {
    try {
      const userId = 1; // For now, we're using a default user
      const scripts = await storage.getMqlScriptsByUserId(userId);
      res.json(scripts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch MQL scripts" });
    }
  });

  app.get("/api/scripts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const script = await storage.getMqlScript(id);
      
      if (!script) {
        return res.status(404).json({ error: "MQL script not found" });
      }
      
      res.json(script);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch MQL script" });
    }
  });

  app.post("/api/scripts", async (req, res) => {
    try {
      const userId = 1; // For now, we're using a default user
      const scriptData = req.body;
      
      const validatedData = insertMqlScriptSchema.safeParse({
        userId,
        name: scriptData.name,
        content: scriptData.content,
        description: scriptData.description || null,
        type: scriptData.type || "indicator",
        language: scriptData.language || "mql5",
        isPublic: scriptData.isPublic || false,
        metadata: scriptData.metadata || null
      });
      
      if (!validatedData.success) {
        return res.status(400).json({ error: validatedData.error.message });
      }
      
      const newScript = await storage.createMqlScript(validatedData.data);
      res.status(201).json(newScript);
    } catch (error) {
      res.status(500).json({ error: "Failed to create MQL script" });
    }
  });

  app.patch("/api/scripts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const scriptData = req.body;
      
      // Partial validation of the update data
      const validatedData = insertMqlScriptSchema.partial().safeParse({
        name: scriptData.name,
        content: scriptData.content,
        description: scriptData.description,
        type: scriptData.type,
        language: scriptData.language,
        isPublic: scriptData.isPublic,
        metadata: scriptData.metadata
      });
      
      if (!validatedData.success) {
        return res.status(400).json({ error: validatedData.error.message });
      }
      
      const updatedScript = await storage.updateMqlScript(id, validatedData.data);
      
      if (!updatedScript) {
        return res.status(404).json({ error: "MQL script not found" });
      }
      
      res.json(updatedScript);
    } catch (error) {
      res.status(500).json({ error: "Failed to update MQL script" });
    }
  });

  app.delete("/api/scripts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const script = await storage.getMqlScript(id);
      
      if (!script) {
        return res.status(404).json({ error: "MQL script not found" });
      }
      
      const success = await storage.deleteMqlScript(id);
      
      if (!success) {
        return res.status(500).json({ error: "Failed to delete MQL script" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete MQL script" });
    }
  });

  // MQL Snippet routes
  app.get("/api/snippets", async (req, res) => {
    try {
      const userId = 1; // For now, we're using a default user
      const snippets = await storage.getMqlSnippetsByUserId(userId);
      res.json(snippets);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch MQL snippets" });
    }
  });

  app.get("/api/snippets/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const snippet = await storage.getMqlSnippet(id);
      
      if (!snippet) {
        return res.status(404).json({ error: "MQL snippet not found" });
      }
      
      res.json(snippet);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch MQL snippet" });
    }
  });

  app.post("/api/snippets", async (req, res) => {
    try {
      const userId = 1; // For now, we're using a default user
      const snippetData = req.body;
      
      const validatedData = insertMqlSnippetSchema.safeParse({
        userId,
        name: snippetData.name,
        content: snippetData.content,
        description: snippetData.description || null,
        category: snippetData.category || "general",
        language: snippetData.language || "mql5",
        tags: snippetData.tags || null
      });
      
      if (!validatedData.success) {
        return res.status(400).json({ error: validatedData.error.message });
      }
      
      const newSnippet = await storage.createMqlSnippet(validatedData.data);
      res.status(201).json(newSnippet);
    } catch (error) {
      res.status(500).json({ error: "Failed to create MQL snippet" });
    }
  });

  app.patch("/api/snippets/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const snippetData = req.body;
      
      // Partial validation of the update data
      const validatedData = insertMqlSnippetSchema.partial().safeParse({
        name: snippetData.name,
        content: snippetData.content,
        description: snippetData.description,
        category: snippetData.category,
        language: snippetData.language,
        tags: snippetData.tags
      });
      
      if (!validatedData.success) {
        return res.status(400).json({ error: validatedData.error.message });
      }
      
      const updatedSnippet = await storage.updateMqlSnippet(id, validatedData.data);
      
      if (!updatedSnippet) {
        return res.status(404).json({ error: "MQL snippet not found" });
      }
      
      res.json(updatedSnippet);
    } catch (error) {
      res.status(500).json({ error: "Failed to update MQL snippet" });
    }
  });

  app.delete("/api/snippets/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const snippet = await storage.getMqlSnippet(id);
      
      if (!snippet) {
        return res.status(404).json({ error: "MQL snippet not found" });
      }
      
      const success = await storage.deleteMqlSnippet(id);
      
      if (!success) {
        return res.status(500).json({ error: "Failed to delete MQL snippet" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete MQL snippet" });
    }
  });

  // Study Library routes
  app.get("/api/library", async (req, res) => {
    try {
      const category = req.query.category as string;
      let items;
      
      if (category) {
        items = await storage.getStudyLibraryByCategory(category);
      } else {
        // This is just a placeholder - we'd need to add a method to get all items
        // For now, let's just return an empty array
        items = [];
      }
      
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch study library items" });
    }
  });

  app.get("/api/library/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const item = await storage.getStudyLibraryItem(id);
      
      if (!item) {
        return res.status(404).json({ error: "Study library item not found" });
      }
      
      res.json(item);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch study library item" });
    }
  });

  app.post("/api/library", async (req, res) => {
    try {
      const itemData = req.body;
      
      const validatedData = insertStudyLibrarySchema.safeParse({
        title: itemData.title,
        content: itemData.content,
        category: itemData.category,
        format: itemData.format || "markdown",
        tags: itemData.tags || null,
        difficulty: itemData.difficulty || "beginner"
      });
      
      if (!validatedData.success) {
        return res.status(400).json({ error: validatedData.error.message });
      }
      
      const newItem = await storage.createStudyLibraryItem(validatedData.data);
      res.status(201).json(newItem);
    } catch (error) {
      res.status(500).json({ error: "Failed to create study library item" });
    }
  });

  app.patch("/api/library/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const itemData = req.body;
      
      // Partial validation of the update data
      const validatedData = insertStudyLibrarySchema.partial().safeParse({
        title: itemData.title,
        content: itemData.content,
        category: itemData.category,
        format: itemData.format,
        tags: itemData.tags,
        difficulty: itemData.difficulty
      });
      
      if (!validatedData.success) {
        return res.status(400).json({ error: validatedData.error.message });
      }
      
      const updatedItem = await storage.updateStudyLibraryItem(id, validatedData.data);
      
      if (!updatedItem) {
        return res.status(404).json({ error: "Study library item not found" });
      }
      
      res.json(updatedItem);
    } catch (error) {
      res.status(500).json({ error: "Failed to update study library item" });
    }
  });

  app.delete("/api/library/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const item = await storage.getStudyLibraryItem(id);
      
      if (!item) {
        return res.status(404).json({ error: "Study library item not found" });
      }
      
      const success = await storage.deleteStudyLibraryItem(id);
      
      if (!success) {
        return res.status(500).json({ error: "Failed to delete study library item" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete study library item" });
    }
  });

  // AI Conversation and Message routes
  app.get("/api/conversations", async (req, res) => {
    try {
      const userId = 1; // For now, we're using a default user
      const conversations = await storage.getAiConversationsByUserId(userId);
      res.json(conversations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch AI conversations" });
    }
  });

  app.get("/api/conversations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      const conversation = await storage.getAiConversation(id);
      
      if (!conversation) {
        return res.status(404).json({ error: "AI conversation not found" });
      }
      
      res.json(conversation);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch AI conversation" });
    }
  });

  app.post("/api/conversations", async (req, res) => {
    try {
      const userId = 1; // For now, we're using a default user
      const convData = req.body;
      
      // Create new conversation
      const newConversation = await storage.createAiConversation({
        userId,
        title: convData.title || "New Conversation",
        isActive: true,
        modelName: convData.modelName || "gpt-4o"
      });
      
      res.status(201).json(newConversation);
    } catch (error) {
      res.status(500).json({ error: "Failed to create AI conversation" });
    }
  });

  app.get("/api/conversations/:id/messages", async (req, res) => {
    try {
      const conversationId = parseInt(req.params.id, 10);
      const conversation = await storage.getAiConversation(conversationId);
      
      if (!conversation) {
        return res.status(404).json({ error: "AI conversation not found" });
      }
      
      const messages = await storage.getAiMessagesByConversationId(conversationId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch conversation messages" });
    }
  });

  app.post("/api/conversations/:id/messages", async (req, res) => {
    try {
      const conversationId = parseInt(req.params.id, 10);
      const messageData = req.body;
      
      // Check if conversation exists
      const conversation = await storage.getAiConversation(conversationId);
      if (!conversation) {
        return res.status(404).json({ error: "AI conversation not found" });
      }
      
      const validatedData = insertAiMessageSchema.safeParse({
        conversationId,
        content: messageData.content,
        role: messageData.role || "user",
        metadata: messageData.metadata || null
      });
      
      if (!validatedData.success) {
        return res.status(400).json({ error: validatedData.error.message });
      }
      
      const newMessage = await storage.createAiMessage(validatedData.data);
      
      // TODO: If this is a user message, we would generate an AI response here
      
      res.status(201).json(newMessage);
    } catch (error) {
      res.status(500).json({ error: "Failed to create message" });
    }
  });

  // Rotas de IA para código MQL5
  app.post("/api/ai/generate", async (req, res) => {
    try {
      const { prompt, model } = req.body;

      if (!prompt) {
        return res.status(400).json({ error: 'Prompt é obrigatório' });
      }

      // Usar módulo de IA do Hugging Face
      const { generateMQL5Code } = await import('./services/huggingface');
      const code = await generateMQL5Code(prompt, model);
      res.json({ generatedCode: code });
    } catch (error) {
      console.error('Erro ao gerar código:', error);
      res.status(500).json({ error: 'Falha ao gerar código MQL5' });
    }
  });

  app.post("/api/ai/improve", async (req, res) => {
    try {
      const { code, instructions, model } = req.body;

      if (!code) {
        return res.status(400).json({ error: 'Código é obrigatório' });
      }

      // Usar módulo de IA do Hugging Face
      const { improveMQL5Code } = await import('./services/huggingface');
      const improvedCode = await improveMQL5Code(
        code, 
        instructions || 'Melhore, otimize e corrija este código', 
        model
      );
      res.json({ improvedCode });
    } catch (error) {
      console.error('Erro ao melhorar código:', error);
      res.status(500).json({ error: 'Falha ao melhorar código MQL5' });
    }
  });

  app.post("/api/ai/analyze", async (req, res) => {
    try {
      const { code, model } = req.body;

      if (!code) {
        return res.status(400).json({ error: 'Código é obrigatório' });
      }

      // Usar módulo de IA do Hugging Face
      const { analyzeMQL5Code } = await import('./services/huggingface');
      const analysis = await analyzeMQL5Code(code, model);
      res.json({ analysis });
    } catch (error) {
      console.error('Erro ao analisar código:', error);
      res.status(500).json({ error: 'Falha ao analisar código MQL5' });
    }
  });

  app.post("/api/ai/ask", async (req, res) => {
    try {
      const { question, model } = req.body;

      if (!question) {
        return res.status(400).json({ error: 'Pergunta é obrigatória' });
      }

      // Usar módulo de IA do Hugging Face
      const { answerQuestion } = await import('./services/huggingface');
      const answer = await answerQuestion(question, model);
      res.json({ answer });
    } catch (error) {
      console.error('Erro ao responder pergunta:', error);
      res.status(500).json({ error: 'Falha ao responder pergunta' });
    }
  });

  // Serve uploaded files
  app.use("/uploads", express.static(uploadsDir));

  const httpServer = createServer(app);
  return httpServer;
}
