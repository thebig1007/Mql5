import { db } from "./db";
import { eq } from "drizzle-orm";
import { 
  users, mqlScripts, mqlSnippets, studyLibrary, 
  aiConversations, aiMessages, backtest, errorLogs, 
  userPreferences
} from "@shared/schema";
import type { 
  User, InsertUser,
  MqlScript, InsertMqlScript,
  MqlSnippet, InsertMqlSnippet,
  StudyLibrary, InsertStudyLibrary,
  AiConversation, InsertAiConversation,
  AiMessage, InsertAiMessage,
  Backtest, InsertBacktest,
  ErrorLog, InsertErrorLog,
  UserPreferences, InsertUserPreferences
} from "@shared/schema";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  // MQL Script operations
  async getMqlScript(id: number): Promise<MqlScript | undefined> {
    const [script] = await db.select().from(mqlScripts).where(eq(mqlScripts.id, id));
    return script;
  }

  async getMqlScriptsByUserId(userId: number): Promise<MqlScript[]> {
    return await db.select().from(mqlScripts).where(eq(mqlScripts.userId, userId));
  }

  async createMqlScript(script: InsertMqlScript): Promise<MqlScript> {
    const [newScript] = await db.insert(mqlScripts).values(script).returning();
    return newScript;
  }

  async updateMqlScript(id: number, script: Partial<InsertMqlScript>): Promise<MqlScript | undefined> {
    const [updatedScript] = await db
      .update(mqlScripts)
      .set({ ...script, updatedAt: new Date() })
      .where(eq(mqlScripts.id, id))
      .returning();
    return updatedScript;
  }

  async deleteMqlScript(id: number): Promise<boolean> {
    const [deletedScript] = await db.delete(mqlScripts).where(eq(mqlScripts.id, id)).returning();
    return !!deletedScript;
  }

  // MQL Snippet operations
  async getMqlSnippet(id: number): Promise<MqlSnippet | undefined> {
    const [snippet] = await db.select().from(mqlSnippets).where(eq(mqlSnippets.id, id));
    return snippet;
  }

  async getMqlSnippetsByUserId(userId: number): Promise<MqlSnippet[]> {
    return await db.select().from(mqlSnippets).where(eq(mqlSnippets.userId, userId));
  }

  async createMqlSnippet(snippet: InsertMqlSnippet): Promise<MqlSnippet> {
    const [newSnippet] = await db.insert(mqlSnippets).values(snippet).returning();
    return newSnippet;
  }

  async updateMqlSnippet(id: number, snippet: Partial<InsertMqlSnippet>): Promise<MqlSnippet | undefined> {
    const [updatedSnippet] = await db
      .update(mqlSnippets)
      .set({ ...snippet, updatedAt: new Date() })
      .where(eq(mqlSnippets.id, id))
      .returning();
    return updatedSnippet;
  }

  async deleteMqlSnippet(id: number): Promise<boolean> {
    const [deletedSnippet] = await db.delete(mqlSnippets).where(eq(mqlSnippets.id, id)).returning();
    return !!deletedSnippet;
  }

  // Study Library operations
  async getStudyLibraryItem(id: number): Promise<StudyLibrary | undefined> {
    const [item] = await db.select().from(studyLibrary).where(eq(studyLibrary.id, id));
    return item;
  }

  async getStudyLibraryByCategory(category: string): Promise<StudyLibrary[]> {
    return await db.select().from(studyLibrary).where(eq(studyLibrary.category, category));
  }

  async createStudyLibraryItem(item: InsertStudyLibrary): Promise<StudyLibrary> {
    const [newItem] = await db.insert(studyLibrary).values(item).returning();
    return newItem;
  }

  async updateStudyLibraryItem(id: number, item: Partial<InsertStudyLibrary>): Promise<StudyLibrary | undefined> {
    const [updatedItem] = await db
      .update(studyLibrary)
      .set({ ...item, updatedAt: new Date() })
      .where(eq(studyLibrary.id, id))
      .returning();
    return updatedItem;
  }

  async deleteStudyLibraryItem(id: number): Promise<boolean> {
    const [deletedItem] = await db.delete(studyLibrary).where(eq(studyLibrary.id, id)).returning();
    return !!deletedItem;
  }

  // AI Conversation operations
  async getAiConversation(id: number): Promise<AiConversation | undefined> {
    const [conversation] = await db.select().from(aiConversations).where(eq(aiConversations.id, id));
    return conversation;
  }

  async getAiConversationsByUserId(userId: number): Promise<AiConversation[]> {
    return await db.select().from(aiConversations).where(eq(aiConversations.userId, userId));
  }

  async createAiConversation(conversation: InsertAiConversation): Promise<AiConversation> {
    const [newConversation] = await db.insert(aiConversations).values(conversation).returning();
    return newConversation;
  }

  async updateAiConversation(id: number, conversation: Partial<InsertAiConversation>): Promise<AiConversation | undefined> {
    const [updatedConversation] = await db
      .update(aiConversations)
      .set({ ...conversation, updatedAt: new Date() })
      .where(eq(aiConversations.id, id))
      .returning();
    return updatedConversation;
  }

  async deleteAiConversation(id: number): Promise<boolean> {
    const [deletedConversation] = await db.delete(aiConversations).where(eq(aiConversations.id, id)).returning();
    return !!deletedConversation;
  }

  // AI Message operations
  async getAiMessagesByConversationId(conversationId: number): Promise<AiMessage[]> {
    return await db.select().from(aiMessages).where(eq(aiMessages.conversationId, conversationId));
  }

  async createAiMessage(message: InsertAiMessage): Promise<AiMessage> {
    const [newMessage] = await db.insert(aiMessages).values(message).returning();
    return newMessage;
  }

  // Backtest operations
  async getBacktest(id: number): Promise<Backtest | undefined> {
    const [test] = await db.select().from(backtest).where(eq(backtest.id, id));
    return test;
  }

  async getBacktestsByUserId(userId: number): Promise<Backtest[]> {
    return await db.select().from(backtest).where(eq(backtest.userId, userId));
  }

  async getBacktestsByScriptId(scriptId: number): Promise<Backtest[]> {
    return await db.select().from(backtest).where(eq(backtest.scriptId, scriptId));
  }

  async createBacktest(test: InsertBacktest): Promise<Backtest> {
    const [newTest] = await db.insert(backtest).values(test).returning();
    return newTest;
  }

  async deleteBacktest(id: number): Promise<boolean> {
    const [deletedTest] = await db.delete(backtest).where(eq(backtest.id, id)).returning();
    return !!deletedTest;
  }

  // Error Log operations
  async getErrorLog(id: number): Promise<ErrorLog | undefined> {
    const [log] = await db.select().from(errorLogs).where(eq(errorLogs.id, id));
    return log;
  }

  async getErrorLogsByUserId(userId: number): Promise<ErrorLog[]> {
    return await db.select().from(errorLogs).where(eq(errorLogs.userId, userId));
  }

  async createErrorLog(log: InsertErrorLog): Promise<ErrorLog> {
    const [newLog] = await db.insert(errorLogs).values(log).returning();
    return newLog;
  }

  // User Preferences operations
  async getUserPreferences(userId: number): Promise<UserPreferences | undefined> {
    const [preferences] = await db.select().from(userPreferences).where(eq(userPreferences.userId, userId));
    return preferences;
  }

  async createOrUpdateUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences> {
    const existingPrefs = await this.getUserPreferences(preferences.userId);
    
    if (existingPrefs) {
      const [updatedPrefs] = await db
        .update(userPreferences)
        .set(preferences)
        .where(eq(userPreferences.userId, preferences.userId))
        .returning();
      return updatedPrefs;
    } else {
      const [newPrefs] = await db.insert(userPreferences).values(preferences).returning();
      return newPrefs;
    }
  }
}