import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import TimelineEvent from "@/components/TimelineEvent";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";

interface Photo {
  id: number;
  filename: string;
  title?: string;
}

interface TimelineEventType {
  id: number;
  title: string;
  description?: string;
  date: string;
  photos: Photo[];
}

export default function Timeline() {
  const [isNewEventModalOpen, setIsNewEventModalOpen] = useState(false);
  const [editingEventId, setEditingEventId] = useState<number | null>(null);
  const [eventTitle, setEventTitle] = useState("");
  const [eventDescription, setEventDescription] = useState("");
  const [eventDate, setEventDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [selectedPhotos, setSelectedPhotos] = useState<string[]>([]);
  const [yearFilter, setYearFilter] = useState<string>("all");

  const { toast } = useToast();

  const { data: timelineEvents = [] } = useQuery<TimelineEventType[]>({
    queryKey: ["/api/timeline"],
  });

  const { data: photos = [] } = useQuery<Photo[]>({
    queryKey: ["/api/photos"],
  });

  const createEventMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/timeline", {
        title: eventTitle,
        description: eventDescription,
        date: new Date(eventDate).toISOString(),
        photoIds: selectedPhotos,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/timeline"] });
      toast({
        title: "Success",
        description: "Memory added to timeline",
      });
      handleCloseEventModal();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleOpenNewEventModal = () => {
    setEditingEventId(null);
    setEventTitle("");
    setEventDescription("");
    setEventDate(format(new Date(), "yyyy-MM-dd"));
    setSelectedPhotos([]);
    setIsNewEventModalOpen(true);
  };

  const handleEditEvent = (id: number) => {
    const event = timelineEvents.find(e => e.id === id);
    if (event) {
      setEditingEventId(id);
      setEventTitle(event.title);
      setEventDescription(event.description || "");
      setEventDate(format(new Date(event.date), "yyyy-MM-dd"));
      setSelectedPhotos(event.photos.map(photo => photo.id.toString()));
      setIsNewEventModalOpen(true);
    }
  };

  const handleCloseEventModal = () => {
    setIsNewEventModalOpen(false);
    setEditingEventId(null);
    setEventTitle("");
    setEventDescription("");
    setEventDate(format(new Date(), "yyyy-MM-dd"));
    setSelectedPhotos([]);
  };

  const handleCreateEvent = () => {
    if (!eventTitle.trim()) {
      toast({
        title: "Error",
        description: "Event title is required",
        variant: "destructive",
      });
      return;
    }
    createEventMutation.mutate();
  };

  const handlePhotoToggle = (photoId: string) => {
    if (selectedPhotos.includes(photoId)) {
      setSelectedPhotos(selectedPhotos.filter(id => id !== photoId));
    } else {
      setSelectedPhotos([...selectedPhotos, photoId]);
    }
  };

  // Filter events by year if a specific year is selected
  const filteredEvents = yearFilter === "all" 
    ? timelineEvents 
    : timelineEvents.filter(event => {
        const eventYear = new Date(event.date).getFullYear().toString();
        return eventYear === yearFilter;
      });

  // Get unique years from timeline events for filtering
  const years = Array.from(new Set(
    timelineEvents.map(event => new Date(event.date).getFullYear().toString())
  )).sort((a, b) => parseInt(b) - parseInt(a)); // Sort descending (most recent first)

  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-['Poppins'] font-bold text-gray-900">Memory Timeline</h1>
        <Button onClick={handleOpenNewEventModal}>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
            <rect width="18" height="18" x="3" y="3" rx="2" ry="2"/>
            <path d="M9 3v18"/>
            <path d="M3 9h18"/>
          </svg>
          Add Memory
        </Button>
      </div>

      <div className="bg-white rounded-xl p-5 shadow-sm mb-8">
        <div className="mb-6">
          <div className="flex items-center mb-4">
            <div className="flex-grow">
              <div className="flex space-x-2 overflow-x-auto pb-2 timeline-scroller">
                <Button 
                  variant={yearFilter === "all" ? "default" : "ghost"} 
                  size="sm" 
                  className="rounded-full"
                  onClick={() => setYearFilter("all")}
                >
                  All Time
                </Button>
                {years.map(year => (
                  <Button 
                    key={year} 
                    variant={yearFilter === year ? "default" : "ghost"} 
                    size="sm" 
                    className="rounded-full"
                    onClick={() => setYearFilter(year)}
                  >
                    {year}
                  </Button>
                ))}
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-neutral-200"></div>
            
            {filteredEvents.length > 0 ? (
              filteredEvents.map(event => (
                <TimelineEvent 
                  key={event.id}
                  id={event.id}
                  title={event.title}
                  description={event.description}
                  date={event.date}
                  photos={event.photos}
                  onEdit={handleEditEvent}
                />
              ))
            ) : (
              <div className="pl-12 pb-8">
                <div className="bg-neutral-50 rounded-lg p-6 border border-neutral-200 text-center">
                  <h3 className="font-medium text-neutral-900 mb-2">Your timeline is empty</h3>
                  <p className="text-neutral-700 mb-4">Add events to your timeline to track your college journey</p>
                  <Button variant="outline" size="sm" onClick={handleOpenNewEventModal}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                      <rect width="18" height="18" x="3" y="3" rx="2" ry="2"/>
                      <path d="M9 3v18"/>
                      <path d="M3 9h18"/>
                    </svg>
                    Create Memory
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* New/Edit Event Modal */}
      <Dialog open={isNewEventModalOpen} onOpenChange={handleCloseEventModal}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingEventId ? "Edit Memory" : "Add New Memory"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="event-title">Memory Title</Label>
              <Input
                id="event-title"
                value={eventTitle}
                onChange={(e) => setEventTitle(e.target.value)}
                placeholder="Give your memory a title"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="event-description">Description</Label>
              <Textarea
                id="event-description"
                value={eventDescription}
                onChange={(e) => setEventDescription(e.target.value)}
                placeholder="Describe this memory"
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="event-date">Date</Label>
              <Input
                id="event-date"
                type="date"
                value={eventDate}
                onChange={(e) => setEventDate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Select Photos</Label>
              <div className="grid grid-cols-3 gap-2 mt-2 max-h-48 overflow-y-auto p-2 border rounded-md">
                {photos.length > 0 ? (
                  photos.map(photo => (
                    <div 
                      key={photo.id} 
                      className={`relative cursor-pointer rounded-md overflow-hidden border-2 ${
                        selectedPhotos.includes(photo.id.toString()) 
                          ? "border-primary" 
                          : "border-transparent"
                      }`}
                      onClick={() => handlePhotoToggle(photo.id.toString())}
                    >
                      <img 
                        src={`/uploads/${photo.filename}`} 
                        alt={photo.title || "Photo"} 
                        className="w-full h-20 object-cover"
                      />
                      {selectedPhotos.includes(photo.id.toString()) && (
                        <div className="absolute top-1 right-1 bg-primary text-white rounded-full p-1">
                          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <polyline points="20 6 9 17 4 12"/>
                          </svg>
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="col-span-3 text-center p-4 text-neutral-500">
                    <p>No photos available. Upload some photos first.</p>
                  </div>
                )}
              </div>
            </div>
            <div className="flex justify-end space-x-2 pt-4">
              <Button variant="outline" onClick={handleCloseEventModal}>
                Cancel
              </Button>
              <Button 
                onClick={handleCreateEvent} 
                disabled={createEventMutation.isPending || !photos.length}
              >
                {createEventMutation.isPending ? "Saving..." : editingEventId ? "Update Memory" : "Add to Timeline"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
