import { useIsMobile } from "@/hooks/use-mobile";
import { Link } from "wouter";

export default function Home() {
  const isMobile = useIsMobile();

  return (
    <div className="container mx-auto py-6">
      <div
        className={`
          grid grid-cols-1 
          ${isMobile ? "" : "md:grid-cols-2"} 
          gap-12 items-center
        `}
      >
        <div className="space-y-6">
          <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl">
            MQL5 Code Editor com IA
          </h1>
          <p className="text-muted-foreground text-lg">
            Crie, edite e corrija códigos MQL5 para MetaTrader 5 com assistência de inteligência artificial. Uma ferramenta leve e rápida para desenvolvimento de algoritmos de trading.
          </p>
          <div className="space-x-4">
            <Link href="/editor">
              <button className="bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-md font-medium">
                Começar a Programar
              </button>
            </Link>
          </div>
        </div>
        <div className="rounded-xl overflow-hidden border shadow-lg">
          <img 
            src="https://media.istockphoto.com/id/1302990577/photo/stock-market-or-forex-trading-graph-in-graphic-concept-suitable-for-financial-investment-or.jpg?s=612x612&w=0&k=20&c=g8eplQKR7hR3gBgr1gCwG1l5pCE-YBvuiJZI3bX8RCg=" 
            alt="Gráficos de trading"
            className="w-full h-auto"
          />
        </div>
      </div>

      <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-card p-6 rounded-lg border shadow-sm">
          <h3 className="text-xl font-bold mb-3">Editor de Código</h3>
          <p className="text-muted-foreground">
            Editor especializado para código MQL5 com recursos de autocorreção e análise de erros.
          </p>
        </div>
        <div className="bg-card p-6 rounded-lg border shadow-sm">
          <h3 className="text-xl font-bold mb-3">Geração com IA</h3>
          <p className="text-muted-foreground">
            Crie códigos MQL5 a partir de descrições em linguagem natural usando modelos de IA.
          </p>
        </div>
        <div className="bg-card p-6 rounded-lg border shadow-sm">
          <h3 className="text-xl font-bold mb-3">Análise de Código</h3>
          <p className="text-muted-foreground">
            Receba feedback detalhado sobre problemas potenciais e otimizações para seu código MQL5.
          </p>
        </div>
      </div>
    </div>
  );
}