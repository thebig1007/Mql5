import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import PhotoCard from "@/components/PhotoCard";
import CollectionCard from "@/components/CollectionCard";
import { useModal } from "@/hooks/use-modal";
import PhotoUploadModal from "@/components/PhotoUploadModal";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Photo {
  id: number;
  title: string;
  location: string;
  filename: string;
  uploadedAt: string;
}

interface Collection {
  id: number;
  name: string;
  description: string;
  coverPhoto: string;
  isShared: boolean;
  createdAt: string;
  updatedAt: string;
}

export default function Photos() {
  const [activeTab, setActiveTab] = useState("photos");
  const [editingPhotoId, setEditingPhotoId] = useState<number | null>(null);
  const [photoTitle, setPhotoTitle] = useState("");
  const [photoLocation, setPhotoLocation] = useState("");

  const [isNewCollectionModalOpen, setIsNewCollectionModalOpen] = useState(false);
  const [collectionName, setCollectionName] = useState("");
  const [collectionDescription, setCollectionDescription] = useState("");
  const [isCollectionShared, setIsCollectionShared] = useState(false);

  const { toast } = useToast();

  const {
    isOpen: isUploadModalOpen,
    openModal: openUploadModal,
    closeModal: closeUploadModal
  } = useModal();

  const { data: photos = [] } = useQuery<Photo[]>({
    queryKey: ["/api/photos"],
  });

  const { data: collections = [] } = useQuery<Collection[]>({
    queryKey: ["/api/collections"],
  });

  const updatePhotoMutation = useMutation({
    mutationFn: async (photoId: number) => {
      await apiRequest("PATCH", `/api/photos/${photoId}`, {
        title: photoTitle,
        location: photoLocation,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/photos"] });
      toast({
        title: "Success",
        description: "Photo details updated successfully",
      });
      handleCloseEditDialog();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createCollectionMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/collections", {
        name: collectionName,
        description: collectionDescription,
        isShared: isCollectionShared,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/collections"] });
      toast({
        title: "Success",
        description: "Collection created successfully",
      });
      handleCloseCollectionModal();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleEditPhoto = (id: number) => {
    const photo = photos.find(p => p.id === id);
    if (photo) {
      setEditingPhotoId(id);
      setPhotoTitle(photo.title || "");
      setPhotoLocation(photo.location || "");
    }
  };

  const handleCloseEditDialog = () => {
    setEditingPhotoId(null);
    setPhotoTitle("");
    setPhotoLocation("");
  };

  const handleUpdatePhoto = () => {
    if (editingPhotoId) {
      updatePhotoMutation.mutate(editingPhotoId);
    }
  };

  const handleOpenCollectionModal = () => {
    setIsNewCollectionModalOpen(true);
  };

  const handleCloseCollectionModal = () => {
    setIsNewCollectionModalOpen(false);
    setCollectionName("");
    setCollectionDescription("");
    setIsCollectionShared(false);
  };

  const handleCreateCollection = () => {
    if (!collectionName.trim()) {
      toast({
        title: "Error",
        description: "Collection name is required",
        variant: "destructive",
      });
      return;
    }
    createCollectionMutation.mutate();
  };

  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-['Poppins'] font-bold text-gray-900">My Photos</h1>
        <div className="flex gap-3">
          <Button onClick={openUploadModal}>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="17 8 12 3 7 8"/>
              <line x1="12" x2="12" y1="3" y2="15"/>
            </svg>
            Upload Photos
          </Button>
          <Button variant="outline" onClick={handleOpenCollectionModal}>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
              <path d="M9 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v5"/>
              <path d="M12 13v8"/>
              <path d="M9 16h6"/>
            </svg>
            New Collection
          </Button>
        </div>
      </div>

      <Tabs defaultValue="photos" value={activeTab} onValueChange={setActiveTab} className="mb-8">
        <TabsList className="mb-6">
          <TabsTrigger value="photos" className="px-6">All Photos</TabsTrigger>
          <TabsTrigger value="collections" className="px-6">Collections</TabsTrigger>
        </TabsList>
        
        <TabsContent value="photos">
          {photos.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {photos.map(photo => (
                <PhotoCard 
                  key={photo.id}
                  id={photo.id}
                  title={photo.title}
                  location={photo.location}
                  uploadedAt={photo.uploadedAt}
                  filename={photo.filename}
                  onEdit={handleEditPhoto}
                />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-xl p-8 text-center">
              <div className="mb-4 flex justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
                  <rect width="18" height="18" x="3" y="3" rx="2" ry="2"/>
                  <circle cx="9" cy="9" r="2"/>
                  <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>
                </svg>
              </div>
              <h3 className="text-lg font-medium text-neutral-800 mb-2">No photos yet</h3>
              <p className="text-neutral-600 mb-4">Upload your first photos to get started</p>
              <Button onClick={openUploadModal}>Upload Photos</Button>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="collections">
          {collections.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {collections.map(collection => (
                <CollectionCard 
                  key={collection.id}
                  id={collection.id}
                  name={collection.name}
                  photoCount={10} // This would ideally come from the API
                  createdAt={collection.createdAt}
                  updatedAt={collection.updatedAt}
                  coverPhoto={collection.coverPhoto}
                  isShared={collection.isShared}
                />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-xl p-8 text-center">
              <div className="mb-4 flex justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
                  <path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>
                  <path d="M12 10v6"/>
                  <path d="m15 13-3 3-3-3"/>
                </svg>
              </div>
              <h3 className="text-lg font-medium text-neutral-800 mb-2">No collections yet</h3>
              <p className="text-neutral-600 mb-4">Create your first collection to organize your photos</p>
              <Button onClick={handleOpenCollectionModal}>Create Collection</Button>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Edit Photo Dialog */}
      <Dialog open={editingPhotoId !== null} onOpenChange={handleCloseEditDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Photo</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={photoTitle}
                onChange={(e) => setPhotoTitle(e.target.value)}
                placeholder="Enter a title for this photo"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={photoLocation}
                onChange={(e) => setPhotoLocation(e.target.value)}
                placeholder="Where was this photo taken?"
              />
            </div>
            <div className="flex justify-end space-x-2 pt-4">
              <Button variant="outline" onClick={handleCloseEditDialog}>
                Cancel
              </Button>
              <Button 
                onClick={handleUpdatePhoto} 
                disabled={updatePhotoMutation.isPending}
              >
                {updatePhotoMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* New Collection Modal */}
      <Dialog open={isNewCollectionModalOpen} onOpenChange={handleCloseCollectionModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create New Collection</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="collection-name">Collection Name</Label>
              <Input
                id="collection-name"
                value={collectionName}
                onChange={(e) => setCollectionName(e.target.value)}
                placeholder="Enter a name for your collection"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="collection-description">Description (Optional)</Label>
              <Input
                id="collection-description"
                value={collectionDescription}
                onChange={(e) => setCollectionDescription(e.target.value)}
                placeholder="Describe your collection"
              />
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="is-shared"
                checked={isCollectionShared}
                onChange={(e) => setIsCollectionShared(e.target.checked)}
                className="rounded border-gray-300 text-primary focus:ring-primary"
              />
              <Label htmlFor="is-shared">Make this collection shareable</Label>
            </div>
            <div className="flex justify-end space-x-2 pt-4">
              <Button variant="outline" onClick={handleCloseCollectionModal}>
                Cancel
              </Button>
              <Button 
                onClick={handleCreateCollection} 
                disabled={createCollectionMutation.isPending}
              >
                {createCollectionMutation.isPending ? "Creating..." : "Create Collection"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <PhotoUploadModal 
        isOpen={isUploadModalOpen} 
        onClose={closeUploadModal}
      />
    </>
  );
}
