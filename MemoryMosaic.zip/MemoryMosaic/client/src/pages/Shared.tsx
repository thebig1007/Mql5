import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

interface Collection {
  id: number;
  name: string;
  description: string;
  coverPhoto: string;
  isShared: boolean;
  createdAt: string;
  updatedAt: string;
}

export default function Shared() {
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [selectedCollection, setSelectedCollection] = useState<Collection | null>(null);
  const [shareEmail, setShareEmail] = useState("");
  const { toast } = useToast();

  const { data: collections = [] } = useQuery<Collection[]>({
    queryKey: ["/api/collections"],
  });

  // Filter only shared collections
  const sharedCollections = collections.filter(collection => collection.isShared);

  const handleOpenShareModal = (collection: Collection) => {
    setSelectedCollection(collection);
    setIsShareModalOpen(true);
  };

  const handleCloseShareModal = () => {
    setIsShareModalOpen(false);
    setSelectedCollection(null);
    setShareEmail("");
  };

  const handleShare = () => {
    if (!shareEmail.trim() || !selectedCollection) {
      toast({
        title: "Error",
        description: "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }

    // In a real implementation, this would make an API request to share the collection
    toast({
      title: "Success",
      description: `Collection "${selectedCollection.name}" shared with ${shareEmail}`,
    });
    handleCloseShareModal();
  };

  // Generate a shareable link (this is a mock implementation)
  const generateShareableLink = (collectionId: number) => {
    return `${window.location.origin}/shared-collection/${collectionId}`;
  };

  const handleCopyLink = (collectionId: number) => {
    const link = generateShareableLink(collectionId);
    navigator.clipboard.writeText(link);
    toast({
      title: "Link Copied",
      description: "Shareable link copied to clipboard",
    });
  };

  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-['Poppins'] font-bold text-gray-900">Shared Collections</h1>
      </div>

      {sharedCollections.length > 0 ? (
        <div className="space-y-6">
          {sharedCollections.map(collection => (
            <div key={collection.id} className="bg-white rounded-xl overflow-hidden shadow-sm">
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/3 h-48 md:h-auto relative">
                  {collection.coverPhoto ? (
                    <img 
                      src={`/uploads/${collection.coverPhoto}`} 
                      alt={collection.name} 
                      className="w-full h-full object-cover" 
                    />
                  ) : (
                    <div className="w-full h-full bg-neutral-200 flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
                        <rect width="18" height="18" x="3" y="3" rx="2" ry="2"/>
                        <circle cx="9" cy="9" r="2"/>
                        <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>
                      </svg>
                    </div>
                  )}
                </div>
                <div className="p-6 md:w-2/3">
                  <h2 className="text-xl font-semibold mb-2">{collection.name}</h2>
                  {collection.description && (
                    <p className="text-neutral-700 mb-4">{collection.description}</p>
                  )}
                  <div className="flex flex-wrap gap-4 mt-6">
                    <Button variant="outline" onClick={() => handleCopyLink(collection.id)}>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                        <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
                        <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
                      </svg>
                      Copy Link
                    </Button>
                    <Button onClick={() => handleOpenShareModal(collection)}>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                        <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/>
                        <polyline points="16 6 12 2 8 6"/>
                        <line x1="12" x2="12" y1="2" y2="15"/>
                      </svg>
                      Share via Email
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-xl p-8 text-center">
          <div className="mb-4 flex justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
              <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/>
              <polyline points="16 6 12 2 8 6"/>
              <line x1="12" x2="12" y1="2" y2="15"/>
            </svg>
          </div>
          <h3 className="text-lg font-medium text-neutral-800 mb-2">No shared collections</h3>
          <p className="text-neutral-600 mb-4">
            You haven't shared any collections yet. Go to My Photos, create a collection, and enable sharing.
          </p>
          <Button href="/photos">Go to My Photos</Button>
        </div>
      )}

      {/* Share Modal */}
      <Dialog open={isShareModalOpen} onOpenChange={handleCloseShareModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Share Collection</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <p className="text-neutral-700">
              Share "{selectedCollection?.name}" with others via email
            </p>
            <div className="space-y-2">
              <Label htmlFor="share-email">Email Address</Label>
              <Input
                id="share-email"
                type="email"
                value={shareEmail}
                onChange={(e) => setShareEmail(e.target.value)}
                placeholder="Enter email address"
              />
            </div>
            <div className="pt-4 space-y-2">
              <Label>Or share with a link</Label>
              <div className="flex">
                <Input
                  disabled
                  value={selectedCollection ? generateShareableLink(selectedCollection.id) : ""}
                  className="flex-1 rounded-r-none"
                />
                <Button
                  className="rounded-l-none"
                  onClick={() => selectedCollection && handleCopyLink(selectedCollection.id)}
                >
                  Copy
                </Button>
              </div>
            </div>
            <div className="flex justify-end space-x-2 pt-4">
              <Button variant="outline" onClick={handleCloseShareModal}>
                Cancel
              </Button>
              <Button onClick={handleShare}>
                Share Collection
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
