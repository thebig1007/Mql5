import React from 'react';
import MqlEditor from '@/components/MqlEditor';

export default function Editor() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-8 bg-gradient-to-r from-purple-600 to-blue-600 text-transparent bg-clip-text">
        Editor de Código MQL5
      </h1>
      <p className="text-muted-foreground mb-8">
        Crie, edite e analise seus códigos MQL5 com assistência de IA. Use a guia "Gerar" para criar código a partir de descrições, 
        ou utilize o analisador para revisar seu código existente.
      </p>
      
      <MqlEditor />
    </div>
  );
}