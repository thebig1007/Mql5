import React, { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { AlertCircle, CheckCircle, Code, FileText, Send, Zap } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

// Componente de Editor para código MQL5
export default function MqlEditor() {
  const [code, setCode] = useState('');
  const [activeTab, setActiveTab] = useState('editor');
  const [loading, setLoading] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [improvedCode, setImprovedCode] = useState('');
  const [codeAnalysis, setCodeAnalysis] = useState('');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [instructions, setInstructions] = useState('');
  const { toast } = useToast();

  // Função para gerar código a partir de uma descrição
  const handleGenerateCode = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, forneça uma descrição do código que deseja gerar.",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      const response = await apiRequest('/api/ai/generate', {
        method: 'POST',
        body: JSON.stringify({ prompt })
      });

      if (response.generatedCode) {
        setGeneratedCode(response.generatedCode);
        setCode(response.generatedCode);
        setActiveTab('editor');
        toast({
          title: "Sucesso",
          description: "Código gerado com sucesso!",
          variant: "default"
        });
      } else {
        throw new Error("Falha ao gerar código");
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao gerar código. Tente novamente.",
        variant: "destructive"
      });
      console.error("Erro ao gerar código:", error);
    } finally {
      setLoading(false);
    }
  };

  // Função para melhorar o código existente
  const handleImproveCode = async () => {
    if (!code.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, insira um código para melhorar.",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      const response = await apiRequest('/api/ai/improve', {
        method: 'POST',
        body: JSON.stringify({ 
          code, 
          instructions: instructions || "Melhore, otimize e corrija este código MQL5."
        })
      });

      if (response.improvedCode) {
        setImprovedCode(response.improvedCode);
        setCode(response.improvedCode);
        setActiveTab('editor');
        toast({
          title: "Sucesso",
          description: "Código melhorado com sucesso!",
          variant: "default"
        });
      } else {
        throw new Error("Falha ao melhorar código");
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao melhorar o código. Tente novamente.",
        variant: "destructive"
      });
      console.error("Erro ao melhorar código:", error);
    } finally {
      setLoading(false);
    }
  };

  // Função para analisar o código
  const handleAnalyzeCode = async () => {
    if (!code.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, insira um código para analisar.",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      const response = await apiRequest('/api/ai/analyze', {
        method: 'POST',
        body: JSON.stringify({ code })
      });

      if (response.analysis) {
        setCodeAnalysis(response.analysis);
        setActiveTab('analysis');
        toast({
          title: "Sucesso",
          description: "Código analisado com sucesso!",
          variant: "default"
        });
      } else {
        throw new Error("Falha ao analisar código");
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao analisar o código. Tente novamente.",
        variant: "destructive"
      });
      console.error("Erro ao analisar código:", error);
    } finally {
      setLoading(false);
    }
  };

  // Função para responder a uma pergunta
  const handleAskQuestion = async () => {
    if (!question.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, faça uma pergunta.",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      const response = await apiRequest('/api/ai/ask', {
        method: 'POST',
        body: JSON.stringify({ question })
      });

      if (response.answer) {
        setAnswer(response.answer);
        setActiveTab('qa');
        toast({
          title: "Resposta recebida",
          description: "Sua pergunta foi respondida!",
          variant: "default"
        });
      } else {
        throw new Error("Falha ao obter resposta");
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao obter resposta. Tente novamente.",
        variant: "destructive"
      });
      console.error("Erro ao responder pergunta:", error);
    } finally {
      setLoading(false);
    }
  };

  // Função para copiar código para a área de transferência
  const handleCopyCode = () => {
    navigator.clipboard.writeText(code);
    toast({
      title: "Código copiado",
      description: "Código copiado para a área de transferência!",
      variant: "default"
    });
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Editor de Código MQL5</CardTitle>
          <CardDescription>
            Crie, edite e melhore seu código MQL5 com assistência de IA
          </CardDescription>
        </CardHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="px-6">
            <TabsList className="grid grid-cols-4 mb-4">
              <TabsTrigger value="editor">
                <Code className="mr-2 h-4 w-4" />
                Editor
              </TabsTrigger>
              <TabsTrigger value="generate">
                <Zap className="mr-2 h-4 w-4" />
                Gerar
              </TabsTrigger>
              <TabsTrigger value="analysis">
                <AlertCircle className="mr-2 h-4 w-4" />
                Análise
              </TabsTrigger>
              <TabsTrigger value="qa">
                <Send className="mr-2 h-4 w-4" />
                Perguntas
              </TabsTrigger>
            </TabsList>
          </div>

          <CardContent>
            <TabsContent value="editor" className="space-y-4">
              <div className="space-y-2">
                <Textarea
                  placeholder="Digite ou cole seu código MQL5 aqui..."
                  className="font-mono h-[500px] resize-none"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                />
              </div>

              <div className="flex space-x-2 justify-between">
                <div className="space-x-2">
                  <Button onClick={handleCopyCode}>
                    Copiar Código
                  </Button>
                  <Button onClick={handleAnalyzeCode} disabled={loading}>
                    {loading ? "Analisando..." : "Analisar Código"}
                  </Button>
                </div>
                <div className="space-x-2">
                  <Input
                    placeholder="Instruções para melhorar o código (opcional)"
                    value={instructions}
                    onChange={(e) => setInstructions(e.target.value)}
                    className="w-96"
                  />
                  <Button onClick={handleImproveCode} disabled={loading}>
                    {loading ? "Melhorando..." : "Melhorar Código"}
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="generate" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="prompt">Descreva o código que você deseja gerar:</Label>
                <Textarea
                  id="prompt"
                  placeholder="Ex: Um indicador MQL5 que calcula a média móvel de 20 períodos e mostra setas para entradas de compra e venda..."
                  className="h-[200px] resize-none"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                />
              </div>

              <Button onClick={handleGenerateCode} disabled={loading} className="w-full">
                {loading ? "Gerando Código..." : "Gerar Código MQL5"}
              </Button>

              {generatedCode && (
                <div className="space-y-2 mt-4">
                  <div className="flex justify-between">
                    <Label>Código Gerado:</Label>
                    <Button variant="outline" size="sm" onClick={() => setCode(generatedCode)}>
                      Usar Este Código
                    </Button>
                  </div>
                  <Textarea
                    readOnly
                    className="font-mono h-[250px] resize-none"
                    value={generatedCode}
                  />
                </div>
              )}
            </TabsContent>

            <TabsContent value="analysis" className="space-y-4">
              {codeAnalysis ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-medium">Análise do Código</h3>
                    <Button variant="outline" size="sm" onClick={handleAnalyzeCode} disabled={loading}>
                      {loading ? "Analisando..." : "Atualizar Análise"}
                    </Button>
                  </div>
                  <div className="bg-muted p-4 rounded-md whitespace-pre-wrap">
                    {codeAnalysis}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <FileText className="mx-auto h-12 w-12 text-muted-foreground" />
                  <h3 className="mt-2 text-lg font-medium">Nenhuma análise disponível</h3>
                  <p className="text-muted-foreground mt-1">
                    Escreva algum código no editor e clique em "Analisar Código"
                  </p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="qa" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="question">Sua pergunta sobre MQL5:</Label>
                <div className="flex space-x-2">
                  <Input
                    id="question"
                    placeholder="Ex: Como usar funções de datas em MQL5?"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                  />
                  <Button onClick={handleAskQuestion} disabled={loading}>
                    {loading ? "Enviando..." : "Perguntar"}
                  </Button>
                </div>
              </div>

              {answer && (
                <div className="space-y-2 mt-4">
                  <Label>Resposta:</Label>
                  <div className="bg-muted p-4 rounded-md whitespace-pre-wrap">
                    {answer}
                  </div>
                </div>
              )}
            </TabsContent>
          </CardContent>
        </Tabs>

        <CardFooter className="flex justify-between">
          <div className="text-sm text-muted-foreground">
            Dica: Use a guia "Gerar" para criar código a partir de descrições em texto.
          </div>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Select>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="MQL5" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mql5">MQL5</SelectItem>
                    <SelectItem value="mql4">MQL4</SelectItem>
                  </SelectContent>
                </Select>
              </TooltipTrigger>
              <TooltipContent>
                <p>Linguagem de programação</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </CardFooter>
      </Card>
    </div>
  );
}