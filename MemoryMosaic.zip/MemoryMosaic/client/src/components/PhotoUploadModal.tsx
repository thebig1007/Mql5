import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dropzone } from "@/components/ui/dropzone";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface PhotoUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Collection {
  id: number;
  name: string;
}

export default function PhotoUploadModal({ isOpen, onClose }: PhotoUploadModalProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [collectionId, setCollectionId] = useState<string>("");
  const [location, setLocation] = useState<string>("");
  const [date, setDate] = useState<string>("");
  const { toast } = useToast();

  const { data: collections = [] } = useQuery<Collection[]>({
    queryKey: ["/api/collections"],
  });

  const uploadMutation = useMutation({
    mutationFn: async () => {
      if (files.length === 0) {
        throw new Error("Please select a file to upload");
      }
      
      const formData = new FormData();
      formData.append("photo", files[0]);
      
      if (location) {
        formData.append("location", location);
      }
      
      if (date) {
        formData.append("takenAt", date);
      }
      
      const photoResponse = await fetch("/api/photos", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      if (!photoResponse.ok) {
        throw new Error("Failed to upload photo");
      }
      
      const photo = await photoResponse.json();
      
      // If a collection is selected, add the photo to the collection
      if (collectionId) {
        await apiRequest("POST", `/api/collections/${collectionId}/photos`, {
          photoId: photo.id,
        });
      }
      
      return photo;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/photos"] });
      if (collectionId) {
        queryClient.invalidateQueries({ queryKey: ["/api/collections"] });
      }
      toast({
        title: "Success",
        description: "Photo uploaded successfully",
      });
      handleClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    setFiles([]);
    setCollectionId("");
    setLocation("");
    setDate("");
    onClose();
  };

  const handleUpload = () => {
    uploadMutation.mutate();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Upload Photos</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-2">
          <Dropzone
            acceptedFileTypes={["image/jpeg", "image/png", "image/gif", "image/webp", "image/heic"]}
            maxFileSizeInMB={20}
            files={files}
            setFiles={setFiles}
            label="Drop your photos here or click to browse"
            description="JPG, PNG, HEIC (max 20MB each)"
          />
          
          <div className="space-y-2">
            <Label htmlFor="collection">Add to Collection</Label>
            <Select value={collectionId} onValueChange={setCollectionId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a collection" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">None</SelectItem>
                {collections.map((collection) => (
                  <SelectItem key={collection.id} value={collection.id.toString()}>
                    {collection.name}
                  </SelectItem>
                ))}
                <SelectItem value="new">Create New Collection...</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="location">Add Location</Label>
            <Input
              id="location"
              placeholder="Search for a location..."
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="date">Add Date</Label>
            <Input
              id="date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button 
              onClick={handleUpload} 
              disabled={uploadMutation.isPending || files.length === 0}
            >
              {uploadMutation.isPending ? "Uploading..." : "Upload Photos"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
