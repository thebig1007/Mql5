import { useState } from "react";

interface SearchBarProps {
  isVisible: boolean;
}

export default function SearchBar({ isVisible }: SearchBarProps) {
  const [searchTerm, setSearchTerm] = useState("");
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Search logic would go here
    console.log("Searching for:", searchTerm);
  };
  
  return (
    <div 
      className={`${
        isVisible ? "block" : "hidden"
      } animate-fade-in bg-white border-t border-neutral-200 py-3 px-4`}
    >
      <div className="container mx-auto">
        <form onSubmit={handleSearch} className="relative">
          <input 
            type="text" 
            placeholder="Search your photos, albums, or memories..." 
            className="w-full pl-10 pr-4 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-all duration-200"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          >
            <circle cx="11" cy="11" r="8"/>
            <path d="m21 21-4.3-4.3"/>
          </svg>
        </form>
      </div>
    </div>
  );
}
