import { ReactNode, useState } from "react";
import Header from "./Header";
import MobileNav from "./MobileNav";
import Chatbot from "./Chatbot";
import PhotoUploadModal from "./PhotoUploadModal";
import FloatingActionButton from "./FloatingActionButton";
import { useModal } from "@/hooks/use-modal";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [showChatbot, setShowChatbot] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  
  const {
    isOpen: isUploadModalOpen,
    openModal: openUploadModal,
    closeModal: closeUploadModal
  } = useModal();

  const toggleChatbot = () => {
    setShowChatbot(!showChatbot);
  };

  const toggleSearch = () => {
    setShowSearch(!showSearch);
  };

  return (
    <div className="flex flex-col min-h-screen bg-neutral-100 font-sans text-neutral-800">
      <Header 
        toggleSearch={toggleSearch} 
        toggleChatbot={toggleChatbot} 
        showSearch={showSearch}
      />
      
      <main className="flex-grow container mx-auto px-4 py-6 pb-20 md:pb-6">
        {children}
      </main>
      
      <MobileNav />
      
      {showChatbot && <Chatbot onClose={() => setShowChatbot(false)} />}
      
      <PhotoUploadModal 
        isOpen={isUploadModalOpen} 
        onClose={closeUploadModal}
      />
      
      <FloatingActionButton onClick={openUploadModal} />
    </div>
  );
}
