import { Link, useLocation } from "wouter";
import SearchBar from "./SearchBar";

interface HeaderProps {
  toggleSearch: () => void;
  toggleChatbot: () => void;
  showSearch: boolean;
}

export default function Header({ toggleSearch, toggleChatbot, showSearch }: HeaderProps) {
  const [location] = useLocation();

  const isActive = (path: string) => {
    return location === path ? "text-primary" : "text-neutral-700 hover:text-primary";
  };

  return (
    <header className="bg-white border-b border-neutral-200 sticky top-0 z-40">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <Link href="/">
            <h1 className="text-2xl font-['Poppins'] font-bold mr-2 cursor-pointer bg-gradient-to-r from-purple-600 to-blue-600 text-transparent bg-clip-text">MQL5 Editor</h1>
          </Link>
          <span className="hidden md:inline-block text-sm bg-accent/10 text-accent px-2 py-0.5 rounded-full">Beta</span>
        </div>
        
        <div className="hidden md:flex items-center space-x-6">
          <Link href="/" className={`${isActive("/")} transition-colors duration-200`}>
            <a className="flex items-center">
              <i className="ri-home-4-line text-xl"></i>
              <span className="ml-1">Home</span>
            </a>
          </Link>
          <Link href="/editor" className={`${isActive("/editor")} transition-colors duration-200`}>
            <a className="flex items-center">
              <i className="ri-code-line text-xl"></i>
              <span className="ml-1">Editor</span>
            </a>
          </Link>
        </div>
        
        <div className="flex items-center space-x-4">
          <button 
            onClick={toggleSearch}
            className="p-2 rounded-full text-neutral-600 hover:bg-neutral-100 transition-colors duration-200"
            aria-label="Search"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-search">
              <circle cx="11" cy="11" r="8"/>
              <path d="m21 21-4.3-4.3"/>
            </svg>
          </button>
          <button 
            onClick={toggleChatbot}
            className="p-2 rounded-full text-neutral-600 hover:bg-neutral-100 transition-colors duration-200"
            aria-label="Chat support"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-message-square">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
          </button>
          <div className="rounded-full bg-neutral-200 h-9 w-9 overflow-hidden">
            <div className="bg-primary h-full w-full flex items-center justify-center text-white font-semibold">
              JD
            </div>
          </div>
        </div>
      </div>
      
      <SearchBar isVisible={showSearch} />
    </header>
  );
}
