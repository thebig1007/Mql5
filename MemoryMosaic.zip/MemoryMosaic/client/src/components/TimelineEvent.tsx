import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Photo {
  id: number;
  filename: string;
  title?: string;
}

interface TimelineEventProps {
  id: number;
  title: string;
  description?: string;
  date: string;
  photos: Photo[];
  onEdit?: (id: number) => void;
}

export default function TimelineEvent({
  id,
  title,
  description,
  date,
  photos,
  onEdit
}: TimelineEventProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const { toast } = useToast();
  
  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/timeline/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/timeline"] });
      toast({
        title: "Success",
        description: "Timeline event deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this memory?")) {
      deleteMutation.mutate();
    }
  };

  return (
    <div className="relative pl-12 pb-8">
      <div className="absolute left-0 top-0 bg-primary w-8 h-8 rounded-full flex items-center justify-center text-white z-10">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect width="18" height="18" x="3" y="3" rx="2" ry="2"/>
          <circle cx="9" cy="9" r="2"/>
          <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>
        </svg>
      </div>
      
      <div className="bg-neutral-50 rounded-lg p-4 border border-neutral-200">
        <div className="flex justify-between items-start mb-3">
          <h3 className="font-medium text-neutral-900">{title}</h3>
          <span className="text-sm text-neutral-500">{format(new Date(date), "MMMM d, yyyy")}</span>
        </div>
        
        {description && <p className="text-neutral-700 mb-3">{description}</p>}
        
        <div className={`grid grid-cols-3 gap-2 mb-3 ${isExpanded ? '' : 'max-h-24 overflow-hidden'}`}>
          {photos.map(photo => (
            <img 
              key={photo.id}
              src={`/uploads/${photo.filename}`}
              alt={photo.title || "Timeline photo"} 
              className="rounded-lg h-24 w-full object-cover" 
            />
          ))}
        </div>
        
        <div className="flex flex-wrap gap-2">
          {photos.length > 3 && (
            <Button 
              variant="ghost" 
              className="text-primary flex items-center text-sm p-0"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>
              {isExpanded ? "Show Less" : "View All"}
            </Button>
          )}
          <Button 
            variant="ghost" 
            className="text-neutral-500 flex items-center text-sm p-0"
            onClick={() => onEdit && onEdit(id)}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
              <path d="M12 20h9"/>
              <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/>
            </svg>
            Edit
          </Button>
          <Button 
            variant="ghost" 
            className="text-neutral-500 flex items-center text-sm p-0"
            onClick={handleDelete}
            disabled={deleteMutation.isPending}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
              <path d="M3 6h18"/>
              <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
              <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
            </svg>
            Delete
          </Button>
          <Button 
            variant="ghost" 
            className="text-neutral-500 flex items-center text-sm p-0"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
              <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/>
              <polyline points="16 6 12 2 8 6"/>
              <line x1="12" x2="12" y1="2" y2="15"/>
            </svg>
            Share
          </Button>
        </div>
      </div>
    </div>
  );
}
