import { Switch, Route } from "wouter";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import Editor from "@/pages/Editor";
import NotFound from "@/pages/not-found";

function App() {
  return (
    <Switch>
      <Route path="/" component={() => <Layout><Home /></Layout>} />
      <Route path="/editor" component={() => <Layout><Editor /></Layout>} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default App;
