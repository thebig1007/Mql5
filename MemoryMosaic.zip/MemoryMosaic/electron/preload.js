// Arquivo preload.js - roda antes da janela renderizar para adicionar APIs específicas
const { contextBridge, ipcRenderer } = require('electron');

// Expõe algumas APIs do Electron para o navegador através do objeto window.electron
contextBridge.exposeInMainWorld('electron', {
  // Obter versão do aplicativo
  getAppVersion: () => ipcRenderer.sendSync('app-version'),
  
  // Outras funções específicas do electron podem ser adicionadas aqui
  ipcRenderer: {
    // Função genérica para enviar mensagens ao processo principal
    send: (channel, data) => {
      ipcRenderer.send(channel, data);
    },
    // Função genérica para ouvir mensagens do processo principal
    on: (channel, func) => {
      ipcRenderer.on(channel, (event, ...args) => func(...args));
    },
    // Remove listener
    removeAllListeners: (channel) => {
      ipcRenderer.removeAllListeners(channel);
    }
  }
});