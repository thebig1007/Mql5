const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const url = require('url');
const fs = require('fs');
const { spawn } = require('child_process');

let mainWindow;
let serverProcess;

const isDev = process.env.NODE_ENV === 'development';
const serverPort = 5000;

function startServer() {
  // Caminho para o script de inicialização do servidor
  const serverPath = path.join(__dirname, '..', 'server', 'index.js');
  
  // Verifica se o arquivo existe antes de tentar iniciar
  if (!fs.existsSync(serverPath)) {
    console.error(`O arquivo do servidor não existe: ${serverPath}`);
    app.quit();
    return;
  }

  console.log(`Iniciando servidor: ${serverPath}`);

  // Inicia o servidor com o Node
  serverProcess = spawn('node', [serverPath], {
    env: {
      ...process.env,
      PORT: serverPort,
      ELECTRON_RUN: true,
      NODE_ENV: isDev ? 'development' : 'production'
    }
  });

  // Logs do servidor
  serverProcess.stdout.on('data', (data) => {
    console.log(`[Servidor]: ${data}`);
  });

  serverProcess.stderr.on('data', (data) => {
    console.error(`[Erro do Servidor]: ${data}`);
  });

  serverProcess.on('close', (code) => {
    console.log(`Processo do servidor finalizado com código: ${code}`);
    if (code !== 0) {
      console.error('O servidor falhou ao iniciar. Verificando logs para detalhes.');
    }
  });
}

function createWindow() {
  // Criando a janela do navegador
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 800,
    minHeight: 600,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, 'icons', 'icon.png')
  });

  // Configurando o título da janela
  mainWindow.setTitle('MQL5 Editor - Assistente de Codificação');
  
  // Carregando a URL do app
  const startUrl = isDev 
    ? `http://localhost:${serverPort}`
    : url.format({
        pathname: path.join(__dirname, '../dist/index.html'),
        protocol: 'file:',
        slashes: true
      });
  
  console.log(`Carregando URL: ${startUrl}`);
  mainWindow.loadURL(startUrl);

  // Abre o DevTools se estiver em desenvolvimento
  if (isDev) {
    mainWindow.webContents.openDevTools();
  }

  // Evento quando a janela é fechada
  mainWindow.on('closed', function () {
    mainWindow = null;
  });
}

// Esse método será chamado quando o Electron terminar de inicializar
app.on('ready', () => {
  startServer();
  
  // Aguarda um pouco para dar tempo ao servidor iniciar
  setTimeout(() => {
    createWindow();
  }, 1500);
});

// Encerra quando todas as janelas estão fechadas
app.on('window-all-closed', function () {
  // No macOS, é comum para aplicativos permanecerem
  // ativos até que o usuário saia explicitamente com Cmd + Q
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', function () {
  // No macOS, é comum recriar uma janela no aplicativo quando o
  // ícone do dock é clicado e não há outras janelas abertas
  if (mainWindow === null) {
    createWindow();
  }
});

// Limpa quando app encerra
app.on('before-quit', () => {
  console.log('Encerrando aplicação, limpando recursos...');
  if (serverProcess) {
    serverProcess.kill();
    console.log('Processo do servidor encerrado.');
  }
});

// IPC Events para comunicação entre renderer e main
ipcMain.on('app-version', (event) => {
  event.returnValue = app.getVersion();
});