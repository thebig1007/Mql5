# Ícones do Aplicativo

Esta pasta contém os ícones utilizados para o instalador Windows do MQL5 Editor.

Arquivos necessários:
- icon.png - Ícone principal (256x256 ou maior)
- icon.ico - Ícone no formato ICO para Windows